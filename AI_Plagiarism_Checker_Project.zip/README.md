
# AI Plagiarism Checker

This project builds a simple NLP-based plagiarism detection system using:
- Text normalization
- TF-IDF vectorization
- Cosine similarity
- Fuzzy matching (RapidFuzz)

It compares an input document against a small sample corpus and flags potentially similar text.

## How to run

1. Install dependencies:
   pip install -r requirements.txt

2. Run:
   python checker.py

3. Edit `corpus.txt` to add more reference documents.
