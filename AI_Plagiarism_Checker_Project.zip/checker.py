
import re
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from rapidfuzz import fuzz

# Download nltk resources (runs once)
nltk.download('punkt')

# Load corpus
with open("corpus.txt", "r", encoding="utf-8") as f:
    corpus = [line.strip() for line in f if line.strip()]

def normalize(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9 ]", "", text)
    return text

def check_plagiarism(text):
    norm_text = normalize(text)
    norm_corpus = [normalize(c) for c in corpus]

    vectorizer = TfidfVectorizer(ngram_range=(1,2))
    tfidf = vectorizer.fit_transform([norm_text] + norm_corpus)

    sims = cosine_similarity(tfidf[0:1], tfidf[1:]).flatten()

    print("\n--- Plagiarism Report ---")
    for i, (doc, score) in enumerate(zip(corpus, sims), start=1):
        fuzzy = fuzz.ratio(norm_text, normalize(doc)) / 100
        print(f"Doc {i}: Cosine={score:.2f}, Fuzzy={fuzzy:.2f}")
        if score > 0.45 or fuzzy > 0.45:
            print("  ⚠ Potential similarity detected!")
        print(f"  Text: {doc}\n")

if __name__ == "__main__":
    sample = input("Enter text to check for plagiarism:\n")
    check_plagiarism(sample)
